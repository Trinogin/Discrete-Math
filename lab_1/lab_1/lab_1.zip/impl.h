#ifndef IMPL_H_INCLUDED
#define IMPL_H_INCLUDED

#pragma once

#pragma warning(disable:4996)

#include<cctype>

int SpaceSkip(char* str, int i);

#endif // !IMPL_H_INCLUDED